
                    // fonction racine carre
                    function racine(){
                      var a = document.getElementById('ecran1').value;
                      var b = Math.sqrt(parseInt(a));
                      ecran2.value = b;
                    }  
                  
                      // fonction cosinus
                      function cosinus(){
                        var a = document.getElementById('ecran1').value;
                        var b = (Math.cos(parseInt(a))*Math.PI)/180;
                        ecran2.value = b;
                      }  
                     
                        // fonction sinus
                        function sinus(){
                          var a = document.getElementById('ecran1').value;
                          var b = Math.sin(parseInt(a));
                          ecran2.value = b;
                        }  
                     
                          // fonction tangente
                          function tangente(){
                            var a = document.getElementById('ecran1').value;
                            var b = Math.tan(parseInt(a));
                            ecran2.value = b;
                          }  
                        
                            // fonction logarithme
                            function logarithme(){
                              var a = document.getElementById('ecran1').value;
                              var b = Math.log(parseInt(a));
                              ecran2.value = b;
                            }  
                          
                              // fonction logarithmeDecimal
                              function logarithmeDecimal(){
                                var a = document.getElementById('ecran1').value;
                                var b = Math.log10(parseInt(a));
                                ecran2.value = b;
                              }  
                           
                                // fonction exponantielle
                                function exponantielle(){
                                  var a = document.getElementById('ecran1').value;
                                  var b = Math.exp(parseInt(a));
                                  ecran2.value = b;
                                }  
                              
                                  // fonction pi
                                  function picos(){
                                    var b = Math.PI;
                                    ecran1.value = b;
                                  }  
                                
                                      // fonction pourcentage
                                      function pourcentage(){
                                        var b = document.getElementById('ecran1').value/100;
                                        ecran2.value = b;
                                      }  
                                    
                                          // fonction factoriel
                                          function factoriel(){
                                            var a = document.getElementById('ecran1').value;
                                            if(a > 0){
                                              var facto = 1;
                                                  for(var i = 1; i <= a; i++){
                                                      facto = facto*i;
                                                  }
                                                  ecran2.value = facto;
                                            }else{ ecran2.value = "ERROR";}
                                          }  
                             
                    // jquery animation pour la sortie du blog
                    $('#glisse1').click(function(){
                        $('#troisieme').animate({
                          left : '-=400px'
                        },1000,'linear');
                    });
                 
                      // jquery animation pour l'entrer du blog
                      $('#glisse2,#glisse3').click(function(){
                          $('#troisieme').animate({
                            left : '+=400px'
                          },1000,'linear');
                      });
                   